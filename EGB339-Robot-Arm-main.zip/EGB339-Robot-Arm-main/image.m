function img = image()    
    img = dobot_sim.getImage;
    imshow(img)
end