# EGB339-Robot-Arm
Assignment for Second semester of 2020. Peter corkes toolbox wasnt used. 
Coppelia Sim was used instead
Tested on inverse kinematics primarily
