function [init_xy, dest_xy] = EGB339_prac_exam_group_XX(dobot_sim, init_xy, dest_xy, use_vision)
%% Setup
    addpath(genpath(pwd));
    input = init_xy; output = dest_xy;
    
%% Initial Shot
    target = [0 0 -45 45 0];
    dobot_sim.setJointPositions(target);
    dobot_sim.getJointPositions();

    pause(4);
    image = dobot_sim.getImage();
    
%% Vision Flag
    if(use_vision == true)
        1;
     % Segment Colours
        % RGB
        R = image(:,:,1); G = image(:,:,2); B = image(:,:,3);
        r = R-image; g = G-image; b = B-image;


        % Binary
        r_grey = rgb2gray(r); g_grey = rgb2gray(g); b_grey = rgb2gray(b);
        red = imbinarize(r_grey); green = imbinarize(g_grey); blue = imbinarize(b_grey);

        % Remove label from Red
        red(1:175, :) = 0;

    % Mapping Data
        %find centres
        r_cent = regionprops(red); g_cent = regionprops(green); b_cent = regionprops(blue);
        r_cent2 = regionprops('table',red,'Circularity','MajorAxisLength'); g_cent2 = regionprops('table',green,'Circularity','MajorAxisLength');
        r_coord = cat(1,r_cent.Centroid); g_coord = cat(1,g_cent.Centroid);

    % Categorise input data
        %repeat colour seperation
        %input = imread('TestSheet1.jpg');
        R = input(:,:,1); G = input(:,:,2); r = R-input; g = G-input;
        r_grey = rgb2gray(r); g_grey = rgb2gray(g); o_grey = rgb2gray(input);
        red = imbinarize(r_grey); green = imbinarize(g_grey); over = ~imbinarize(o_grey);

        %find coordinates to order
        rr = regionprops(red); gg = regionprops(green); overall = regionprops(over);
        r_position = round(cat(1,rr.Centroid)); g_position = round(cat(1,gg.Centroid)); o_position = round(cat(1,overall.Centroid));

        %colour, shape and size 
        %0,1:red,green   0,1,2:circle,square,triangle   0,1:small,large
        init = ones(3,3);

        %COLOUR, SHAPE and SIZE
        %red
        [m,~] = size(r_position);
        r_circ_prop = regionprops('table',red,'Circularity','MajorAxisLength','MinorAxisLength');
        r_circ = cat(1,r_circ_prop.Circularity); r_len = cat(1,r_circ_prop.MajorAxisLength);
        circle = r_circ>0.9; square = (0.63<r_circ) & (r_circ<0.87); triangle = r_circ<0.63; 
        for i = 1:3 %each shape
            for j = 1:m %each x coord for each colour
                if(abs(o_position(i,1)-r_position(j,1)) < 10)
                    init(1,i) = 0; %shape i is red
                    if(circle(j,1))
                        init(2,i) = 0; %shape i is a circle
                    end
                    if(square(j,1))
                        init(2,i) = 1; %shape i is a square
                    end
                    if(triangle(j,1))
                        init(2,i) = 2; %shape i is a triangle
                    end

                    if(r_len(j)>225)
                        init(3,i) = 1; %shape is large
                    else
                        init(3,i) = 0; %shape is small
                    end
                end         
            end
        end

        %green
        [m,~] = size(g_position);
        g_circ_prop = regionprops('table',green,'Circularity','MajorAxisLength');
        g_circ = cat(1,g_circ_prop.Circularity); g_len = cat(1,g_circ_prop.MajorAxisLength);
        circle = g_circ>0.9; triangle = g_circ<0.63; square = (0.63<g_circ) & (g_circ<0.87);
        for i = 1:3 %each shape
            for j = 1:m %each x coord for each colour        
                if(abs(o_position(i,1)-g_position(j,1)) < 10)
                    init(1,i) = 1; %shape i is green
                    if(circle(j,1))
                        init(2,i) = 0; %shape i is a circle
                    end
                    if(square(j,1))
                        init(2,i) = 1; %shape i is a square
                    end
                    if(triangle(j,1))
                        init(2,i) = 2; %shape i is a triangle
                    end

                    if(g_len(j)>225)
                        init(3,i) = 1; %shape is large
                    else
                        init(3,i) = 0; %shape is small
                    end
                end
            end
        end

    % Categorise output data %SAME AS ABOVE    
        %repeat colour seperation
        %output = imread('TestSheet8.jpg');
        R = output(:,:,1); G = output(:,:,2); r = R-output; g = G-output;
        r_grey = rgb2gray(r); g_grey = rgb2gray(g); o_grey = rgb2gray(output);
        red = imbinarize(r_grey); green = imbinarize(g_grey); over = ~imbinarize(o_grey);

        %find coordinates to order
        rr = regionprops(red); gg = regionprops(green); overall = regionprops(over);
        r_position = round(cat(1,rr.Centroid)); g_position = round(cat(1,gg.Centroid)); o_position = round(cat(1,overall.Centroid));

        %colour, shape and size 
        %0,1:red,green   0,1,2:circle,square,triangle   0,1:small,large
        out = ones(3,3);

        %COLOUR, SHAPE and SIZE
        %red
        [m,~] = size(r_position);
        r_circ_prop = regionprops('table',red,'Circularity','MajorAxisLength','MinorAxisLength');
        r_circ = cat(1,r_circ_prop.Circularity); r_len = cat(1,r_circ_prop.MajorAxisLength);
        circle = r_circ>0.9; square = (0.63<r_circ) & (r_circ<0.87); triangle = r_circ<0.63; 
        for i = 1:3 %each shape
            for j = 1:m %each x coord for each colour
                if(abs(o_position(i,1)-r_position(j,1)) < 10)
                    out(1,i) = 0; %shape i is red
                    if(circle(j,1))
                        out(2,i) = 0; %shape i is a circle
                    end
                    if(square(j,1))
                        out(2,i) = 1; %shape i is a square
                    end
                    if(triangle(j,1))
                        out(2,i) = 2; %shape i is a triangle
                    end

                    if(r_len(j)>225)
                        out(3,i) = 1; %shape is large
                    else
                        out(3,i) = 0; %shape is small
                    end
                end         
            end
        end

        %green
        [m,~] = size(g_position);
        g_circ_prop = regionprops('table',green,'Circularity','MajorAxisLength','MinorAxisLength');
        g_circ = cat(1,g_circ_prop.Circularity); g_len = cat(1,g_circ_prop.MajorAxisLength);
        circle = g_circ>0.9; triangle = g_circ<0.63; square = (0.63<g_circ) & (g_circ<0.87);
        for i = 1:3 %each shape
            for j = 1:m %each x coord for each colour        
                if(abs(o_position(i,1)-g_position(j,1)) < 10)
                    out(1,i) = 1; %shape i is green
                    if(circle(j,1))
                        out(2,i) = 0; %shape i is a circle
                    end
                    if(square(j,1))
                        out(2,i) = 1; %shape i is a square
                    end
                    if(triangle(j,1))
                        out(2,i) = 2; %shape i is a triangle
                    end

                    if(g_len(j)>225)
                        out(3,i) = 1; %shape is large
                    else
                        out(3,i) = 0; %shape is small
                    end
                end
            end
        end

    % Match Input
        %0,1:red,green   0,1,2:circle,square,triangle   0,1:small,large
        input_coords = [0,0,0;0,0,0];

        for i = 1:3
            colour = init(1,i);
            shape = init(2,i);
            siz = init(3,i);

            if colour == 1 %green
                size_check = cat(1,g_cent2.MajorAxisLength);
                shape_check = cat(1,g_cent2.Circularity);
                if shape == 0 %circle
                    if siz == 0 %small
                        for j = 1:6
                            if (shape_check(j)>0.9)
                                if (size_check(j)<45)
                                    input_coords(1,i) = g_coord(j,1);
                                    input_coords(2,i) = g_coord(j,2);
                                end
                            end
                        end 
                    end
                    if siz == 1 %large
                        for j = 1:6
                            if (shape_check(j)>0.9)
                                if (size_check(j)>45)
                                    input_coords(1,i) = g_coord(j,1);
                                    input_coords(2,i) = g_coord(j,2);
                                end
                            end
                        end 
                    end
                end

                if shape == 1 %square
                    if siz == 0 %small
                        for j = 1:6
                            if ((0.70<shape_check(j)) && (shape_check(j)<0.87))
                                if (size_check(j)<45)
                                    input_coords(1,i) = g_coord(j,1);
                                    input_coords(2,i) = g_coord(j,2);
                                end
                            end
                        end 
                    end
                    if siz == 1 %large
                        for j = 1:6
                            if ((0.70<shape_check(j)) && (shape_check(j)<0.87))
                                if (size_check(j)>45)
                                    input_coords(1,i) = g_coord(j,1);
                                    input_coords(2,i) = g_coord(j,2);
                                end
                            end
                        end 
                    end
                end

                if shape == 2 %square
                    if siz == 0 %small
                        for j = 1:6
                            if (shape_check(j)<0.63)
                                if (size_check(j)<45)
                                    input_coords(1,i) = g_coord(j,1);
                                    input_coords(2,i) = g_coord(j,2);
                                end
                            end
                        end 
                    end
                    if siz == 1 %large
                        for j = 1:6
                            if (shape_check(j)<0.63)
                                if (size_check(j)>45)
                                    input_coords(1,i) = g_coord(j,1);
                                    input_coords(2,i) = g_coord(j,2);
                                end
                            end
                        end 
                    end
                end
            end



            if colour == 0 %red
                size_check = cat(1,r_cent2.MajorAxisLength);
                shape_check = cat(1,r_cent2.Circularity);
                if shape == 0 %circle
                    if siz == 0 %small
                        for j = 1:6
                            if (shape_check(j)>0.9)                
                                if (size_check(j)<45)
                                    input_coords(1,i) = r_coord(j,1);
                                    input_coords(2,i) = r_coord(j,2);
                                end
                            end
                        end 
                    end
                    if siz == 1 %large
                        for j = 1:6
                            if (shape_check(j)>0.9)
                                if (size_check(j)>45)
                                    input_coords(1,i) = r_coord(j,1);
                                    input_coords(2,i) = r_coord(j,2);
                                end
                            end
                        end 
                    end
                end

                if shape == 1 %square
                    if siz == 0 %small
                        for j = 1:6
                            if ((0.70<shape_check(j)) && (shape_check(j)<0.87))
                                if (size_check(j)<45)
                                    input_coords(1,i) = r_coord(j,1);
                                    input_coords(2,i) = r_coord(j,2);
                                end
                            end
                        end 
                    end
                    if siz == 1 %large
                        for j = 1:6
                            if ((0.70<shape_check(j)) && (shape_check(j)<0.87))
                                if (size_check(j)>45)
                                    input_coords(1,i) = r_coord(j,1);
                                    input_coords(2,i) = r_coord(j,2);
                                end
                            end
                        end 
                    end
                end

                if shape == 2 %triangle
                    if siz == 0 %small
                        for j = 1:6
                            if (shape_check(j)<0.63)
                                if (size_check(j)<45)
                                    input_coords(1,i) = r_coord(j,1);
                                    input_coords(2,i) = r_coord(j,2);
                                end
                            end
                        end 
                    end
                    if siz == 1 %large
                        for j = 1:6
                            if (shape_check(j)<0.63)
                                if (size_check(j)>45)
                                    input_coords(1,i) = r_coord(j,1);
                                    input_coords(2,i) = r_coord(j,2);
                                end
                            end
                        end 
                    end
                end
            end

        end

        % Match Output %SAME AS ABOVE
        %0,1:red,green   0,1,2:circle,square,triangle   0,1:small,large
        output_coords = [0,0,0;0,0,0];

        for i = 1:3
            colour = out(1,i);
            shape = out(2,i);
            siz = out(3,i);

            if colour == 1 %green
                size_check = cat(1,g_cent2.MajorAxisLength);
                shape_check = cat(1,g_cent2.Circularity);
                if shape == 0 %circle
                    if siz == 0 %small
                        for j = 1:6
                            if (shape_check(j)>0.9)
                                if (size_check(j)<45)
                                    output_coords(1,i) = g_coord(j,1);
                                    output_coords(2,i) = g_coord(j,2);
                                end
                            end
                        end 
                    end
                    if siz == 1 %large
                        for j = 1:6
                            if (shape_check(j)>0.9)
                                if (size_check(j)>45)
                                    output_coords(1,i) = g_coord(j,1);
                                    output_coords(2,i) = g_coord(j,2);
                                end
                            end
                        end 
                    end
                end

                if shape == 1 %square
                    if siz == 0 %small
                        for j = 1:6
                            if ((0.70<shape_check(j)) && (shape_check(j)<0.87))
                                if (size_check(j)<45)
                                    output_coords(1,i) = g_coord(j,1);
                                    output_coords(2,i) = g_coord(j,2);
                                end
                            end
                        end 
                    end
                    if siz == 1 %large
                        for j = 1:6
                            if ((0.70<shape_check(j)) && (shape_check(j)<0.87))
                                if (size_check(j)>45)
                                    output_coords(1,i) = g_coord(j,1);
                                    output_coords(2,i) = g_coord(j,2);
                                end
                            end
                        end 
                    end
                end

                if shape == 2 %triangle
                    if siz == 0 %small
                        for j = 1:6
                            if (shape_check(j)<0.7)
                                if (size_check(j)<45)
                                    output_coords(1,i) = g_coord(j,1);
                                    output_coords(2,i) = g_coord(j,2);
                                end
                            end
                        end 
                    end
                    if siz == 1 %large
                        for j = 1:6
                            if (shape_check(j)<0.7)
                                if (size_check(j)>45)
                                    output_coords(1,i) = g_coord(j,1);
                                    output_coords(2,i) = g_coord(j,2);
                                end
                            end
                        end 
                    end
                end
            end



            if colour == 0 %red
                size_check = cat(1,r_cent2.MajorAxisLength);
                shape_check = cat(1,r_cent2.Circularity);
                if shape == 0 %circle
                    if siz == 0 %small
                        for j = 1:6
                            if (shape_check(j)>0.9)                
                                if (size_check(j)<45)
                                    output_coords(1,i) = r_coord(j,1);
                                    output_coords(2,i) = r_coord(j,2);
                                end
                            end
                        end 
                    end
                    if siz == 1 %large
                        for j = 1:6
                            if (shape_check(j)>0.9)
                                if (size_check(j)>45)
                                    output_coords(1,i) = r_coord(j,1);
                                    output_coords(2,i) = r_coord(j,2);
                                end
                            end
                        end 
                    end
                end

                if shape == 1 %square
                    if siz == 0 %small
                        for j = 1:6
                            if ((0.70<shape_check(j)) && (shape_check(j)<0.87))
                                if (size_check(j)<45)
                                    output_coords(1,i) = r_coord(j,1);
                                    output_coords(2,i) = r_coord(j,2);
                                end
                            end
                        end 
                    end
                    if siz == 1 %large
                        for j = 1:6
                            if ((0.70<shape_check(j)) && (shape_check(j)<0.87))
                                if (size_check(j)>45)
                                    output_coords(1,i) = r_coord(j,1);
                                    output_coords(2,i) = r_coord(j,2);
                                end
                            end
                        end 
                    end
                end

                if shape == 2 %triangle
                    if siz == 0 %small
                        for j = 1:6
                            if (shape_check(j)<0.7)
                                if (size_check(j)<45)
                                    output_coords(1,i) = r_coord(j,1);
                                    output_coords(2,i) = r_coord(j,2);
                                end
                            end
                        end 
                    end
                    if siz == 1 %large
                        for j = 1:6
                            if (shape_check(j)<0.7)
                                if (size_check(j)>45)
                                    output_coords(1,i) = r_coord(j,1);
                                    output_coords(2,i) = r_coord(j,2);
                                end
                            end
                        end 
                    end
                end
            end

        end
    else
        input_coords = init_xy';
        output_coords = dest_xy';
        itemp = init_xy';
        dtemp = dest_xy';
        
        corner = [625,577]; %origin coords for set camera angle
        dx = [0.95,0.952]; %mm per pixel for set camera angle

        for i = 1:3
            input_coords(2,i) = round( corner(2)-((itemp(1,i)-0.4)/dx(1)) );
            input_coords(1,i) = round( corner(1)-((itemp(2,i)+1.05)/dx(2)) );

            output_coords(2,i) = round( corner(2)-((dtemp(1,i)-0.4)/dx(1)) );
            output_coords(1,i) = round( corner(1)-((dtemp(2,i)+1.05)/dx(2)) );
        end
    end

%% Arm movement
origin = [320,493]; % using default target
for i = 1:3 %for each cylinder
    for j = 1:2
        %input or output
        if j == 1
            locations = input_coords;
        else
            locations = output_coords;
        end
        
        %x and y pixel map
        x = (locations(1,i)-origin(1));
        y = (locations(2,i)-origin(2));
        r = sqrt((x^2) + (y^2)); %proportional to distance
        rot_angl = atand(y/x); %rotational angle
        

        %fix for direction
        if(locations(1,i)<320)
            rotate = 90 - rot_angl;
        else
            rotate = -90 - rot_angl;
        end
        
        %arm adders
        add = (r-155.986)*0.22; %lower/further
        sub = -(r-155.986)*0.44; %higher/closer
        diff = add+sub;
        if r<140
            fix = -10;
        else
            fix = 0;
        end
        
        %move the arm
        target = [rotate 20+add 53+sub -200 0]; 
        dobot_sim.setJointPositions(target);
        pause(4);
        target = [rotate 20+add 53+sub -73+abs(diff)+fix 0]; 
        dobot_sim.setJointPositions(target);
        pause(1);
        
        %grab or place
        if j == 1
            dobot_sim.setSuctionCup(true);
        else
            dobot_sim.setSuctionCup(false);
        end
    end
end

target = [0 0 -45 -200 0];
dobot_sim.setJointPositions(target);
pause(2);

%% Coords

corner = [625,577]; %origin coords for set camera angle
dx = [0.95,0.952]; %mm per pixel for set camera angle
init_xy = input_coords;
dest_xy = output_coords;

for i = 1:3
    init_xy(2,i) = round( (((corner(1)-input_coords(1,i))*dx(1))+0.4), 1);
    init_xy(1,i) = round( (((corner(2)-input_coords(2,i))*dx(2))-1.05), 1);
    
    dest_xy(2,i) = round( (((corner(1)-output_coords(1,i))*dx(1))+0.4), 1);
    dest_xy(1,i) = round( (((corner(2)-output_coords(2,i))*dx(2))-1.05), 1);
end

init_xy = init_xy';
dest_xy = dest_xy';

end